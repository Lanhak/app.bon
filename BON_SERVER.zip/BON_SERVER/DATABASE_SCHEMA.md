# DATABASE_SCHEMA

## Core relationships

`users` 1→N `vip_keys` 1→N `key_devices`; `vip_keys` 1→N `vip_data`.
`users` 1→N `balance_transactions`, `wallet_requests`, `app_credits`, `job_completions`.
`job_completions` is unique on `(platform, job_id, device_hash)` to prevent duplicate completion records.

## Tables

- `users`: accounts, role, balance, timestamps.
- `vip_keys`: VIP key value, duration, expiry, owner, device limit/status.
- `key_devices`: SHA-256 device binding per key.
- `devices`: normalized device registry.
- `vip_data`: JSONB mirror of the VIP response/local state; not present in the legacy MySQL dump but included as a compatibility mirror because the APK explicitly uses `vip_data`.
- `balance_transactions`: immutable balance ledger.
- `wallet_requests`: deposits/withdrawals and processing state.
- `fb_jobs`: Facebook job pool.
- `tiktok_jobs`: TikTok job pool.
- `job_completions`: idempotent completion history.
- `job_reports`: job failure reports.
- `app_credits`: `addHistory` credit audit/rate-limit table.
- `announcements`: APK update/announcement response.
- `settings`: JSONB system settings.
- `sessions`: optional server-side session metadata; the current web login uses signed cookies.

All tables use PostgreSQL identity columns, constraints, indexes, and `TIMESTAMPTZ`. No secret is stored in SQL.
