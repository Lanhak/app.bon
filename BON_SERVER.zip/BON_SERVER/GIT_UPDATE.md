# Git update after every BON_SERVER change

After replacing/updating `BON_SERVER.zip` in the repository, run:

```bash
git add BON_SERVER.zip README.md .env.example API_MAP.md VIP_FLOW.md TEST_REPORT.md DATABASE_SCHEMA.md
git commit -m "Update BON_SERVER backend"
git push origin main
```

If the repository uses another branch, replace `main` with that branch. Never commit `.env` or real credentials.
