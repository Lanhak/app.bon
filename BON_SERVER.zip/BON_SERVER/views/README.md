The web UI is rendered from `routes/web.js` to keep compatibility forms and legacy routes in one deployable Node application. These directories are reserved for future extracted templates/assets.
