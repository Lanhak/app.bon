const assert=require('assert');
const fs=require('fs');
const path=require('path');
for(const f of ['server.js','routes/web.js','routes/compat.js','services/db.js','services/vip.js'])assert(fs.existsSync(path.join(__dirname,'..',f)));
const schema=fs.readFileSync(path.join(__dirname,'..','db/schema.sql'),'utf8');
for(const t of ['users','vip_keys','key_devices','vip_data','balance_transactions','wallet_requests','fb_jobs','tiktok_jobs','job_completions','job_reports','app_credits','announcements','settings'])assert(schema.includes(`CREATE TABLE IF NOT EXISTS ${t}`),t);
const compat=fs.readFileSync(path.join(__dirname,'..','routes/compat.js'),'utf8');
for(const p of ['/checkkey/api/key.php','/checkkey/api/check_date_key.php','/checkkey/api/api_golike_fb.php','/checkkey/api/api_golike_tiktok.php','/checkkey/','/api/check-key.php','/checkkey/api/announcement.json','/Key_Free/'])assert(compat.includes(p),p);
console.log('SMOKE PASS: source/contract checks');
