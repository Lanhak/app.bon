const crypto = require('crypto');
const db = require('./db');
function sha256(v){ return crypto.createHash('sha256').update(String(v)).digest('hex'); }
function validDevice(v){ return typeof v === 'string' && v.trim() !== ''; }
async function loadKey(c,key,forUpdate=false){
  const q = await c.query(`SELECT * FROM vip_keys WHERE key_value=$1 LIMIT 1${forUpdate?' FOR UPDATE':''}`,[key]);
  return q.rows[0] || null;
}
async function validateAndBind(c,key,deviceId,{bind=true}={}){
  const k=await loadKey(c,key,bind); if(!k) return {ok:false,status:'invalid',msg:'Key VIP không tồn tại'};
  if(k.status==='disabled') return {ok:false,status:'disabled',msg:'Key VIP đã bị khóa',key:k.key_value};
  if(!k.expires_at || new Date(k.expires_at)<=new Date()){
    await c.query("UPDATE vip_keys SET status='expired',updated_at=NOW() WHERE id=$1",[k.id]);
    return {ok:false,status:'expired',msg:'Key VIP đã hết hạn',key:k.key_value,end_date:k.expires_at};
  }
  let deviceCount=0, hash='', known=false;
  if(validDevice(deviceId)){
    hash=sha256(deviceId);
    const d=await c.query('SELECT id FROM key_devices WHERE key_id=$1 AND device_hash=$2 LIMIT 1',[k.id,hash]);
    known=!!d.rowCount;
    const cnt=await c.query('SELECT COUNT(*)::int n FROM key_devices WHERE key_id=$1',[k.id]); deviceCount=cnt.rows[0].n;
    if(!known && deviceCount>=Number(k.device_limit)) return {ok:false,status:'device_limit',msg:'Key VIP đã đạt giới hạn thiết bị',key:k.key_value,api_key:k.key_value,device_limit:Number(k.device_limit)};
    if(known) await c.query('UPDATE key_devices SET last_seen=NOW() WHERE id=$1',[d.rows[0].id]);
    else { await c.query('INSERT INTO key_devices(key_id,device_hash) VALUES($1,$2)',[k.id,hash]); deviceCount++; }
    await c.query(`INSERT INTO devices(device_hash,device_id,last_seen) VALUES($1,$2,NOW()) ON CONFLICT(device_hash) DO UPDATE SET device_id=EXCLUDED.device_id,last_seen=NOW()`,[hash,deviceId]);
  }
  const data={key:k.key_value,api_key:k.key_value,vip:true,duration_hours:Number(k.duration_hours),expires_at:k.expires_at,endDate:k.expires_at,end_date:k.expires_at,create_date:k.created_at,device_ID:validDevice(deviceId)?deviceId:'',device_id:validDevice(deviceId)?deviceId:'',device_count:deviceCount,device_limit:Number(k.device_limit)};
  await c.query(`INSERT INTO vip_data(key_id,user_id,device_hash,api_key,data,updated_at) VALUES($1,$2,$3,$4,$5::jsonb,NOW())`,[k.id,k.user_id||null,hash||null,k.key_value,JSON.stringify(data)]).catch(()=>{});
  return {ok:true,status:'success',msg:'Xác thực Server thành công: Key VIP hợp lệ!',...data};
}
module.exports={sha256,validateAndBind,loadKey};
