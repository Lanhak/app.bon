const crypto=require('crypto');
function sign(payload){
 const raw=Buffer.from(JSON.stringify(payload)).toString('base64url');
 const sig=crypto.createHmac('sha256',process.env.SESSION_SECRET||'dev-only-change-me').update(raw).digest('base64url');
 return raw+'.'+sig;
}
function verify(token){
 try{const [raw,sig]=String(token||'').split('.');if(!raw||!sig)return null;const exp=crypto.createHmac('sha256',process.env.SESSION_SECRET||'dev-only-change-me').update(raw).digest('base64url');if(Buffer.byteLength(sig)!==Buffer.byteLength(exp)||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(exp)))return null;const p=JSON.parse(Buffer.from(raw,'base64url').toString());if(p.exp&&p.exp<Date.now())return null;return p;}catch{return null;}}
function setSession(res,u){const token=sign({uid:Number(u.id||u.uid),role:u.role,email:u.email,username:u.username||'',exp:Date.now()+7*86400000});res.setHeader('Set-Cookie',`bon_session=${token}; Path=/; HttpOnly; SameSite=Lax${process.env.NODE_ENV==='production'?'; Secure':''}`);}
function clearSession(res){res.setHeader('Set-Cookie','bon_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax');}
function current(req){const h=req.headers.cookie||'';const m=h.match(/(?:^|; )bon_session=([^;]+)/);return verify(m&&m[1]);}
function requireUser(req,res,next){const u=current(req);if(!u||u.role!=='user')return res.redirect('/?error='+encodeURIComponent('Vui lòng đăng nhập.'));req.session=u;next();}
function requireAdmin(req,res,next){const u=current(req);if(!u||u.role!=='admin')return res.redirect('/admin?error='+encodeURIComponent('Vui lòng đăng nhập quản trị.'));req.session=u;next();}
function hashPassword(password){return new Promise((resolve,reject)=>crypto.scrypt(password,crypto.randomBytes(16),64,(e,k)=>{if(e)return reject(e);resolve(k.toString('hex'));}));}
function verifyPassword(password,stored){return new Promise((resolve,reject)=>{const [salt,key]=String(stored).split('$');if(!salt||!key)return resolve(false);crypto.scrypt(password,Buffer.from(salt,'hex'),64,(e,k)=>{if(e)return reject(e);resolve(crypto.timingSafeEqual(k,Buffer.from(key,'hex')));});});}
async function makeHash(password){const salt=crypto.randomBytes(16).toString('hex');return salt+'$'+await hashPasswordWithSalt(password,salt);}
function hashPasswordWithSalt(password,salt){return new Promise((resolve,reject)=>crypto.scrypt(password,Buffer.from(salt,'hex'),64,(e,k)=>e?reject(e):resolve(k.toString('hex'))));}
module.exports={setSession,clearSession,current,requireUser,requireAdmin,makeHash,verifyPassword};
