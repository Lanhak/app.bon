const db=require('./db');
const vip=require('./vip');
async function getKey(key){return db.query('SELECT id,user_id,expires_at,status FROM vip_keys WHERE key_value=$1 LIMIT 1',[key]).then(r=>r.rows[0]||null)}
async function authKey(key){const k=await getKey(key);if(!k)return {ok:false,msg:'Key VIP không tồn tại'};if(k.status!=='active'||!k.expires_at||new Date(k.expires_at)<=new Date())return {ok:false,msg:'Key VIP hết hạn hoặc bị khóa'};return {ok:true,k}}
async function complete(platform,key,deviceId,jobId,amount){
 return db.withTx(async c=>{
  const a=await authKeyTx(c,key);if(!a.ok)throw Object.assign(new Error(a.msg),{publicMessage:a.msg});
  const hash=vip.sha256(deviceId||'');
  const ins=await c.query(`INSERT INTO job_completions(platform,job_id,device_hash,user_id,amount,status) VALUES($1,$2,$3,$4,$5,'done') ON CONFLICT(platform,job_id,device_hash) DO NOTHING RETURNING id`,[platform,jobId,hash,a.k.user_id,amount]);
  if(ins.rowCount){await c.query(`UPDATE ${platform==='facebook'?'fb_jobs':'tiktok_jobs'} SET used_count=used_count+1 WHERE id=$1`,[jobId]);}
  return {newCompletion:!!ins.rowCount};
 });
}
async function authKeyTx(c,key){const q=await c.query('SELECT id,user_id,expires_at,status FROM vip_keys WHERE key_value=$1 LIMIT 1',[key]);const k=q.rows[0];if(!k)return {ok:false};if(k.status!=='active'||!k.expires_at||new Date(k.expires_at)<=new Date())return {ok:false};return {ok:true,k}}
module.exports={getKey,authKey,complete};
