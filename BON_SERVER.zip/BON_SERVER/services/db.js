const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

const DATABASE_URL = process.env.DATABASE_URL;
const pool = DATABASE_URL ? new Pool({
  connectionString: DATABASE_URL,
  max: Number(process.env.DB_POOL_MAX || 10),
  connectionTimeoutMillis: Number(process.env.DB_CONNECT_TIMEOUT_MS || 5000),
  idleTimeoutMillis: 30000,
  ssl: process.env.DB_SSL === 'false' ? false : { rejectUnauthorized: false }
}) : null;

let dbReady = false;
let lastDbError = null;

async function query(text, params) {
  if (!pool) throw new Error('DATABASE_URL is not configured');
  try { const r = await pool.query(text, params); dbReady = true; lastDbError = null; return r; }
  catch (e) { dbReady = false; lastDbError = e; console.error('[DB] query failed:', e.message); throw e; }
}

async function withTx(fn) {
  if (!pool) throw new Error('DATABASE_URL is not configured');
  const c = await pool.connect();
  try { await c.query('BEGIN'); const out = await fn(c); await c.query('COMMIT'); return out; }
  catch (e) { await c.query('ROLLBACK').catch(()=>{}); throw e; }
  finally { c.release(); }
}

async function migrate() {
  if (!pool) return false;
  try {
    const schema = fs.readFileSync(path.join(__dirname,'..','db','schema.sql'),'utf8');
    await pool.query(schema);
    await pool.query(`CREATE TABLE IF NOT EXISTS schema_migrations (id VARCHAR(120) PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
    const dir = path.join(__dirname,'..','db','migrations');
    for (const file of fs.readdirSync(dir).filter(x=>x.endsWith('.sql')).sort()) {
      const exists = await pool.query('SELECT 1 FROM schema_migrations WHERE id=$1',[file]);
      if (!exists.rowCount) {
        const sql = fs.readFileSync(path.join(dir,file),'utf8');
        if (sql.trim()) await pool.query(sql);
        await pool.query('INSERT INTO schema_migrations(id) VALUES($1)',[file]);
      }
    }
    dbReady = true; lastDbError = null; console.log('[DB] migration complete'); return true;
  } catch (e) { dbReady = false; lastDbError = e; console.error('[DB] migration failed:', e.message); return false; }
}

async function waitForDb() {
  const delay = Number(process.env.DB_RETRY_MS || 5000);
  while (true) {
    try { if (await migrate()) return; }
    catch (e) { console.error('[DB] retry error:', e.message); }
    await new Promise(r=>setTimeout(r, delay));
  }
}

module.exports = { pool, query, withTx, migrate, waitForDb, get dbReady(){return dbReady;}, get lastDbError(){return lastDbError;} };
