# BON_SERVER

Node.js + PostgreSQL backend rebuilt from the supplied `BON_TOOL.apk` and `WEB_BON_TOOL.ZIP`.

## Source-of-truth findings

The supplied web source contains the legacy MySQL schema and these compatibility endpoints:

- `GET /checkkey/api/key.php?APIKey=...`
- `GET /checkkey/api/check_date_key.php?APIKey=...&end_date_local=...&number_phone_local=...&device_id_local=...`
- `GET /checkkey/api/api_golike_fb.php?action=get_jobs|complete_job|report_job`
- `GET /checkkey/api/api_golike_tiktok.php?action=complete_job`
- `POST /checkkey/` action `addHistory`
- `POST /api/check-key.php`
- `GET /checkkey/api/announcement.json`
- `GET /Key_Free/?key=...`
- `GET /statistics`

APK string analysis independently confirms the production base URL `https://bonshop.onrender.com`, the same key/date endpoints, the FB/TikTok endpoints, `/checkkey/`, `/statistics`, and local `vip_data`, `api_key`, `KEY_DEVICE_ID`, `device_id_local`, `end_date_local`, and `number_phone_local` fields.

## DATABASE SETUP

1. Create PostgreSQL.
2. Set `DATABASE_URL`.
3. Copy `.env.example` to environment variables.
4. `npm install`.
5. Run `node admin-init.js` once with `ADMIN_EMAIL` and `ADMIN_PASSWORD` to create/update the admin account with a salted scrypt hash.
6. `npm start`.

The server opens `0.0.0.0:$PORT` before waiting for PostgreSQL. It retries migrations when PostgreSQL is temporarily unavailable.

`db/schema.sql` is idempotent. `db/migrations/*.sql` are applied once and recorded in `schema_migrations`. No migration drops or resets data.

## Render

Set:

- `DATABASE_URL`
- `SESSION_SECRET`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
- `CHECKKEY_ADMIN_KEY`
- `API_SECRET`
- `PUBLIC_URL=https://bonshop.onrender.com`

Render supplies `PORT`; the application does not hard-code it.

## APK compatibility

The VIP flow keeps the legacy response fields used by the source/API contract: `status`, `msg`, `key`, `api_key`, `vip`, `duration_hours`, `expires_at`, `endDate`, `end_date`, `create_date`, `device_ID`, `device_id`, `device_count`, and `device_limit`.

Device binding uses SHA-256 of the exact `device_id_local` value supplied by the app, matching the legacy PHP source.

`addHistory` requires `CHECKKEY_ADMIN_KEY`. This value is intentionally an environment variable; do not commit the legacy secret.

## Security

No production password, database URL, session secret, or API secret is stored in this repository. SQL is parameterized. Helmet, rate limiting, signed HTTP-only sessions, scrypt password hashing, and transactional balance changes are enabled.

## Important test limitation

A production PostgreSQL instance and the Android runtime are not available inside this build environment. Therefore `TEST_REPORT.md` explicitly distinguishes static/source-contract tests from tests that require a live Render/PostgreSQL deployment and the physical APK. No claim of 100% runtime compatibility is made without those tests.
