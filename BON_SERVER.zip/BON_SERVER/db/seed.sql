-- Development-only seed. No real credentials are stored here.
INSERT INTO announcements(is_show,title,message,version_code,version,download_url,force_update)
SELECT FALSE,'🚀 BON SHOP','BON SHOP đang hoạt động ổn định.',10,'5.0.0','https://bonshop.onrender.com/BON_TOOL.apk',FALSE
WHERE NOT EXISTS (SELECT 1 FROM announcements);
INSERT INTO settings(key,value)
VALUES ('system', '{"service":"bon-shop","version":"1.0.0"}'::jsonb)
ON CONFLICT (key) DO NOTHING;
-- Create the admin account through npm run admin-init so the password is hashed from ADMIN_PASSWORD.
