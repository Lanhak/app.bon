# VIP_FLOW

## Confirmed flow from source

`APK input Key`
→ `GET /checkkey/api/key.php?APIKey=...`
→ response `status`
→ local `vip_data/api_key`
→ periodic `GET /checkkey/api/check_date_key.php?APIKey=...&end_date_local=...&number_phone_local=...&device_id_local=...`
→ SHA-256(device_id_local)
→ `key_devices`
→ device-limit decision
→ valid VIP state
→ FB/TikTok API calls
→ `POST /checkkey/` `addHistory`
→ `balance_transactions` + `app_credits`.

The APK string table also contains `Found device_id from KEY_DEVICE_ID`, `Found device_id from vip_data`, `Found VIP key from 'api_key' field`, and `Found VIP key from 'key' field`, confirming the local-cache branches.

## VIP decision matrix

A valid active unexpired key is accepted. A disabled, missing, expired, or over-limit device is rejected with the legacy `status/msg` pattern. The first new device is bound when `device_id_local` is supplied; a known device is refreshed.

## Important boundary

The supplied WEB database has no `vip_data` SQL table; `vip_data` is confirmed as an APK/local-cache field. This server additionally stores a JSONB compatibility mirror so the server can preserve the state without replacing the app's local cache with a boolean.
