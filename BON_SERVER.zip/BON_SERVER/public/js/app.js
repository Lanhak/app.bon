// Reserved for extracted UI behavior. Current UI uses small inline compatibility handlers.
