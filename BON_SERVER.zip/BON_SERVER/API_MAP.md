# API_MAP

| Method | Path | Request | Success contract | Error contract | Source |
|---|---|---|---|---|---|
| GET | `/checkkey/api/key.php` | `APIKey`, optional `device_id` | `status=success`, `key`, `api_key`, `vip`, dates/device fields | `status=invalid|disabled|expired|device_limit`, `msg` | PHP + APK URL strings |
| GET | `/checkkey/api/check_date_key.php` | `APIKey`, `end_date_local`, `number_phone_local`, `device_id_local` | same VIP fields, `status=success` | non-success status + `msg` | PHP comments + APK strings |
| GET | `/checkkey/api/api_golike_fb.php` | `action`, `APIKey`, `device_id_local`, job fields | `get_jobs`: `data.id/job_id/link/type/reaction/object_id/price_per_after_cost/fix_coin`; complete/report: success/message | `success=false,message` | PHP comments/source |
| GET | `/checkkey/api/api_golike_tiktok.php` | `action=complete_job`, `APIKey`, `ads_id`, `account_id`, `device_id_local` | `success=true,message,data.fix_coin` | `success=false,message` | PHP source |
| POST | `/checkkey/` | JSON `action=addHistory,keyadmin,name_tool,device_id,money` | `success=true,data.username,balance,money` | `success=false,message` | PHP source + APK strings |
| POST | `/api/check-key.php` | `X-API-Key`, JSON `key/key_value,device_hash` | `success/status/message/key/expires_at/device_limit` | `success=false,status,message` | WEB source |
| GET | `/checkkey/api/announcement.json` | none | announcement fields incl. `is_show`, `version_code`, `download_url`, force flags | safe fallback | WEB + APK strings |
| GET | `/Key_Free/` | `key` | HTML key display | HTML without key | WEB + APK URL |
| GET | `/statistics` | none | HTML statistics | temporary-unavailable HTML | WEB + APK URL |
| POST | `/login` | login_id, pass | signed session | redirect error | WEB |
| POST | `/register` | username,email,pass | signed session | redirect error | WEB |
| POST | `/user/deposit` | bank,amount,note | wallet request | redirect error | WEB |
| POST | `/user/withdraw` | bank,account_number,account_name,amount | held balance + wallet request | redirect error | WEB |
| POST | `/user/buy` | hours | VIP key + transaction | redirect error | WEB |
| POST | `/admin/*` | module-specific forms | admin management | redirect error | WEB |
