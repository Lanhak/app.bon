<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');

function response(array $data, int $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $config = require dirname(__DIR__, 2) . '/config.php';
} catch (Throwable $e) {
    response([
        'status' => 'server_error',
        'msg' => 'Không tải được config.php'
    ], 500);
}

try {
    $db = $config['db'];
    $pdo = new PDO(
        "mysql:host={$db['host']};dbname={$db['name']};charset=utf8mb4",
        $db['user'],
        $db['pass'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

    /*
     * Đảm bảo cột created_at tồn tại trong vip_keys.
     * KHÔNG dùng INFORMATION_SCHEMA (InfinityFree rất hay treo),
     * thay bằng try/catch: nếu SELECT lỗi do thiếu cột thì ALTER.
     */
    try {
        $stmt = $pdo->prepare("SELECT created_at FROM vip_keys LIMIT 1");
        $stmt->execute();
    } catch (Throwable $e) {
        try {
            $pdo->exec("ALTER TABLE vip_keys ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP");
        } catch (Throwable $e2) {
            response([
                'status' => 'server_error',
                'msg' => 'Không tải được dữ liệu key'
            ], 500);
        }
    }

    /*
     * BON SHOP VIP CHECK API - kiểm tra thời hạn key định kỳ
     *
     * App HTool_Tiktok_Prov6 gọi (e2/h.java -> d()):
     * GET /checkkey/api/check_date_key.php
     *   ?APIKey=KEY
     *   &end_date_local=EPOCH_SECONDS      (hạn local do app tự nhớ)
     *   &number_phone_local=DEVICE_COUNT   (số thiết bị app đang biết)
     *   &device_id_local=DEVICE_ID         (id thiết bị hiện tại)
     *
     * App mong đợi (MainActivity checkServerVipKey):
     *   - Thành công: status = "success"  (so sánh equalsIgnoreCase)
     *   - Thất bại:   status != "success" -> app xoá vip_data, khoá tool
     *
     * Đây cũng là điểm server gán thiết bị vào key (device_id_local)
     * và chặn key dùng quá giới hạn thiết bị.
     */
    $key = trim((string)($_GET['APIKey'] ?? $_GET['api_key'] ?? $_GET['key'] ?? ''));
    $deviceId = trim((string)($_GET['device_id_local'] ?? $_GET['device_id'] ?? $_GET['deviceId'] ?? ''));

    if ($key === '') {
        response([
            'status' => 'invalid',
            'msg' => 'Thiếu APIKey'
        ], 400);
    }

    $stmt = $pdo->prepare(
        "SELECT id, key_value, duration_hours, expires_at, device_limit, status, created_at
         FROM vip_keys
         WHERE key_value = ?
         LIMIT 1"
    );
    $stmt->execute([$key]);
    $vip = $stmt->fetch();

    if (!$vip) {
        response([
            'status' => 'invalid',
            'msg' => 'Key VIP không tồn tại',
            'key' => $key,
            'api_key' => $key
        ]);
    }

    if ($vip['status'] === 'disabled') {
        response([
            'status' => 'disabled',
            'msg' => 'Key VIP đã bị khóa',
            'key' => $vip['key_value'],
            'api_key' => $vip['key_value']
        ]);
    }

    $expires = $vip['expires_at'];
    if (!$expires || strtotime($expires) <= time()) {
        $pdo->prepare("UPDATE vip_keys SET status='expired' WHERE id=?")
            ->execute([$vip['id']]);

        response([
            'status' => 'expired',
            'msg' => 'Key VIP đã hết hạn',
            'key' => $vip['key_value'],
            'api_key' => $vip['key_value'],
            'end_date' => $expires
        ]);
    }

    /*
     * Gán thiết bị vào key qua device_id_local.
     * Nếu key đã đạt giới hạn thiết bị mà thiết bị này chưa đăng ký
     * -> trả status != "success" để app chặn dùng trên thiết bị khác.
     */
    $deviceCount = 0;
    $deviceIdBound = '';
    if ($deviceId !== '') {
        $deviceHash = hash('sha256', $deviceId);

        $find = $pdo->prepare(
            "SELECT id FROM key_devices
             WHERE key_id=? AND device_hash=?
             LIMIT 1"
        );
        $find->execute([$vip['id'], $deviceHash]);
        $known = $find->fetch();

        $countStmt = $pdo->prepare(
            "SELECT COUNT(*) FROM key_devices WHERE key_id=?"
        );
        $countStmt->execute([$vip['id']]);
        $deviceCount = (int)$countStmt->fetchColumn();

        if (!$known && $deviceCount >= (int)$vip['device_limit']) {
            response([
                'status' => 'device_limit',
                'msg' => 'Key VIP đã đạt giới hạn thiết bị',
                'key' => $vip['key_value'],
                'api_key' => $vip['key_value'],
                'device_limit' => (int)$vip['device_limit']
            ]);
        }

        if ($known) {
            $pdo->prepare("UPDATE key_devices SET last_seen=NOW() WHERE id=?")
                ->execute([$known['id']]);
        } else {
            $pdo->prepare(
                "INSERT INTO key_devices(key_id, device_hash)
                 VALUES(?, ?)"
            )->execute([$vip['id'], $deviceHash]);
            $deviceCount++;
        }
        $deviceIdBound = $deviceId;
    }

    response([
        'success' => true,
        'status' => 'success',
        'msg' => 'Xác thực Server thành công: Key VIP hợp lệ!',
        'key' => $vip['key_value'],
        'api_key' => $vip['key_value'],
        'vip' => true,
        'duration_hours' => (int)$vip['duration_hours'],
        'expires_at' => $expires,
        'endDate' => $expires,
        'end_date' => $expires,
        'create_date' => $vip['created_at'],
        'device_ID' => $deviceIdBound,
        'device_id' => $deviceIdBound,
        'device_count' => $deviceCount,
        'device_limit' => (int)$vip['device_limit']
    ]);

} catch (Throwable $e) {
    response([
        'status' => 'server_error',
        'msg' => 'Lỗi kết nối máy chủ'
    ], 500);
}
