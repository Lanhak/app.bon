<?php
return [
 'db'=>[
   'host'=>'sql213.infinityfree.com',
   'name'=>'if0_42605251_vipkeys',
   'user'=>'if0_42605251',
   'pass'=>'Hientrang2007'
 ],
 'api_secret'=>'5jaOqjXofEizsYZ8GkHbD5iZmiaNA6RKXuxGuQArRdM',
 'admin_email'=>'akklanh84@gmail.com',
 'admin_password'=>'ttht2007',
 'prices'=>[
   24=>2000,
   720=>50000,
   2160=>120000
 ],
 'banks'=>[
   'Sacombank'=>['account'=>'050088931308','name'=>'DIEU LANH'],
   'VietinBank'=>['account'=>'101886569909','name'=>'DIEU LANH']
 ],
 'withdraw_min'=>10000,
];
